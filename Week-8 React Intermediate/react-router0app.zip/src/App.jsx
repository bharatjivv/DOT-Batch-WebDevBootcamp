import React from "react";
import { Routes, Route } from "react-router-dom";
import Home from "./components/Home";
import About from "./components/About";
import Labs from "./components/Labs";
import Support from "./components/Support";
import NotFound from "./components/Notfound";
import { Link, NavLink } from "react-router-dom";
import Mainheader from "./components/Mainheader";

function App() {
  return (
    <div>
      <nav>
        <ul>
          <li>
            <NavLink to="/"> Home</NavLink>
          </li>
          <li>
            <NavLink to="/about"> About</NavLink>
          </li>
          <li>
            <NavLink to="/support"> Support</NavLink>
          </li>
          <li>
            <NavLink to="/labs"> Labs</NavLink>
          </li>
        </ul>
      </nav>

      <Routes>
        <Route path="/" element={<Mainheader />}>
          <Route index element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/support" element={<Support />} />
          <Route path="/labs" element={<Labs />} />
          <Route path="*" element={<NotFound />} />
        </Route>
      </Routes>
    </div>
  );
}

export default App;
