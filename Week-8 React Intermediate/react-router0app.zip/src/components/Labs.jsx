import React from "react";
import { Navigate, useNavigate } from "react-router-dom";

const Labs = () => {
  const navigate = useNavigate();

  function clickHandler() {
    // navigate to about page
    navigate("/about");
  }

  return (
    <div>
      <h1>Labs</h1>
      <p>This is the Labs page.</p>
      <button onClick={clickHandler}>Move to About Page</button>
    </div>
  );
};

export default Labs;
