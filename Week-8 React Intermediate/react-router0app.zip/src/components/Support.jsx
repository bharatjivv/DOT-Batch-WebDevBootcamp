import React from 'react';

const Support = () => {
  return (
    <div>
      <h1>Support</h1>
      <p>This is the support page.</p>
    </div>
  );
};

export default Support;