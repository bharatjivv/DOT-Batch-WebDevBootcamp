import { useState } from "react";
import "./App.css";

export default function App() {
  // const[firstName, setFirstName] = useState("");
  // const[lastName, setLastName] = useState("");

  // function changeFirstNameHandler(event) {
  //   console.log("Printing First Name :");
  //   setFirstName(event.target.value);
  // }

  // function changeLastNameHandler(event) {
  //   console.log("Printing Last Name :");
  //   setLastName(event.target.value);
  // }

  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    comments: "",
    isVisible: true,
    mode: "",
    favCar: "",
  });

  // console.log(formData.firstName);
  // console.log(formData.lastName);
  // console.log(formData.email);
  // console.log(formData.comments);
  // console.log(formData);

  // function changeHandler(event) {
  //   setFormData(prevFormData => {
  //     return {
  //       ...prevFormData,
  //       [event.target.name]: event.target.value
  //     }
  //   })
  // }

  function changeHandler(event) {
    const { name, value, type, checked} = event.target;
    setFormData((prevFormData) => {
      return {
        ...prevFormData,
        [name]: type === "checkbox" ? checked : value,
      };
    });
  }

  function submitHandler (event) {
    event.preventDefault();
    //print
    console.log("Finally printing entire form ka data ");
    console.log(formData);
  }







  
  return (
    <div>
      {/* <form>
        <input
          type="text"
          placeholder = "first name"
          onChange={changeFirstNameHandler}
          />

        <br/>

        <input
          type="text"
          placeholder = "last name"
          onChange={changeLastNameHandler}/>
      </form> */}

      <form onSubmit={submitHandler}>
        <input
          type="text"
          placeholder="first name"
          onChange={changeHandler}
          name="firstName"
          value={formData.firstName}
        />

        <br />
        <br />

        <input
          type="text"
          placeholder="last name"
          onChange={changeHandler}
          name="lastName"
          value={formData.lastName}
        />

        <br />
        <br />

        <input
          type="text"
          placeholder="email"
          onChange={changeHandler}
          name="email"
          value={formData.email}
        />

        <br />
        <br />

        <textarea
          placeholder="Comment here"
          onChange={changeHandler}
          name="comments"
          value={formData.comments}
        />

        <br />
        <br />

        <input
          type="checkbox"
          onChange={changeHandler}
          name="isVisible"
          id="isVisible"
          checked={formData.isVisible}
        />
        <label htmlFor="isVisible">Am I visible?</label>

        <br />
        <br />

        <fieldset>
          <legend> Mode : </legend>
          <input
            type="radio"
            onChange={changeHandler}
            name="mode"
            value="online mode"
            id="online-mode"
            checked={formData.mode === "online-mode"}
          />
          <label htmlFor="online-mode"> Online Mode </label>

          <input
            type="radio"
            onChange={changeHandler}
            name="mode"
            value="offline mode"
            id="offline-mode"
            checked={formData.mode === "offline-mode"}
          />
          <label htmlFor="offline-mode"> Offline Mode </label>
        </fieldset>

        <br />
        <br />

        <label htmlFor="Favourite Car">What's Favourite Car</label>
        <select name="favCar" onChange={changeHandler} value={formData.favCar}>

          <option value="Tesla">Tesla</option>
          <option value="Range Rover Velar"> Range Rover Velar</option>
          <option value="Mercedes AMG GTR"> Mercedes AMG GTR</option>.{" "}
          <option value="Rolls Royce"> Rolls Royce</option>
          <option value="Paggani"> Paggani</option>
          <option value="Kogenizag"> Kogenizag</option>
        </select>

        <br/>        
        <br/>


      {/* <input type="submit" value='submit' /> */}
      <button>Submit</button>

          
      </form>
    </div>
  );
}
