import { useState } from "react";
import "./App.css";

function App() {
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    country: "India",
    streetaddress: "",
    city: "",
    state: "",
    postalcode: "",
    comments: false,
    candidates: false,
    offers: false,
    pushNotifications: "",
  });

  function changeHandler(event) {
    const { name, value, checked, type } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));
  }

  function submitHandler(event) {
    event.preventDefault();
    console.log("Finally printing the form data");
    console.log(formData);
  }

  return (
    <main className="flex justify-center gap-4 flex-col min-h-screen items-center ">
      <form onSubmit={submitHandler}>
        <label htmlFor="firstName"> First Name</label>
        <br />
        <input
          type="text"
          name="firstName"
          placeholder="Love"
          value={formData.firstName}
          onChange={changeHandler}
          className="border-2 border-grey rounded-md p-2"
        />
        <br />
        <br />

        <label htmlFor="lastName"> Last Name</label>
        <br />
        <input
          type="text"
          name="lastName"
          placeholder="Babbar"
          value={formData.lastName}
          onChange={changeHandler}
          className="border-2 border-grey rounded-md p-2"
        />
        <br />
        <br />

        <label htmlFor="email"> Email Address</label>
        <br />
        <input
          type="text"
          name="email"
          placeholder="love@abcd"
          value={formData.email}
          onChange={changeHandler}
          className="border-2 border-grey rounded-md p-2"
        />
        <br />
        <br />

        <label htmlFor="Country"> Country</label>

        <select
          name="country"
          id="country"
          value={formData.country}
          onChange={changeHandler}
          className="border-2 border-grey rounded-md p-2 m-5"
        >
          <option>India</option>
          <option>China</option>
          <option>Pakistan</option>
          <option>Bhutan</option>
          <option>Nepal</option>
        </select>

        <br />
        <br />
        <label htmlFor="streetaddress"> Street Address</label>
        <br />
        <input
          type="text"
          name="streetaddress"
          placeholder="Street Address"
          value={formData.streetaddress}
          onChange={changeHandler}
          className="border-2 border-grey rounded-md p-2"
        />
        <br />
        <br />

        <label htmlFor="city"> City</label>
        <br />
        <input
          type="text"
          name="city"
          placeholder="City"
          value={formData.city}
          onChange={changeHandler}
          className="border-2 border-grey rounded-md p-2"
        />
        <br />
        <br />

        <label htmlFor="state"> State</label>
        <br />
        <input
          type="text"
          name="state"
          placeholder="State"
          value={formData.state}
          onChange={changeHandler}
          className="border-2 border-grey rounded-md p-2"
        />
        <br />
        <br />

        <label htmlFor="postalcode"> Postal Code</label>
        <br />
        <input
          type="text"
          name="postalcode"
          placeholder="Postal Code"
          value={formData.postalcode}
          onChange={changeHandler}
          className="border-2 border-grey rounded-md p-2"
        />
        <br />
        <br />

        <fieldset>
          <legend> By Email</legend>

          <div className="flex">
            <input
              id="comments"
              name="comments"
              type="checkbox"
              checked={formData.comments}
              onChange={changeHandler}
            ></input>
            <div>
              <label htmlFor="comments"> Comments</label>
              <p> Get notified when someones posts comment on a posting. </p>
            </div>
          </div>

          <div className="flex">
            <input
              id="candidates"
              name="candidates"
              type="checkbox"
              checked={formData.candidates}
              onChange={changeHandler}
            ></input>
            <div>
              <label htmlFor="candidates"> Candidates</label>
              <p> Get notified when candidate applies for a job. </p>
            </div>
          </div>

          <div className="flex">
            <input
              id="offers"
              name="offers"
              type="checkbox"
              checked={formData.offers}
              onChange={changeHandler}
            ></input>
            <div>
              <label htmlFor="offers"> Offers</label>
              <p> Get notified when candidate accepts or rejects an offer. </p>
            </div>
          </div>
        </fieldset>

        <br />
        <br />

        <fieldset>
          <legend> Push Notifications </legend>
          <p> These are delivered via SMS to your mobile phone</p>

          <input
            type="radio"
            id="pushEverything"
            name="pushNotifications"
            value="Everything"
            onChange={changeHandler}
          />

          <label htmlFor="pushEverything"> Everything </label>

          <br />
          <input
            type="radio"
            id="pushEmail"
            name="pushNotifications"
            value="Same as email"
            onChange={changeHandler}
          />

          <label htmlFor="pushEmail"> Same as Email </label>

          <br />
          <input
            type="radio"
            id="pushNothing"
            name="pushNotifications"
            value="No push notification"
            onChange={changeHandler}
          />

          <label htmlFor="pushNothing"> No push notification </label>
        </fieldset>

        <button className="bg-blue-500 text-white font-bold rounded py-2 px-4">
          Save
        </button>
      </form>
    </main>
  );
}

export default App;
